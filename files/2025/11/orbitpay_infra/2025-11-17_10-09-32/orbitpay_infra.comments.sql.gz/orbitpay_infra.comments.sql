/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `comments` VALUES
(1,1,5,"The amount has already been claimed by the user via the payment link sent to the email of the user. we have checked and confirm the amount has been claimed. with order id : O-01K32WCPYN16HKFE1K3JSQYMWD","2025-08-20 19:32:15","2025-08-20 19:32:15"),
(2,2,5,"The amount has already been claimed by the user via the payment link sent to the email of the user. we have checked and confirm the amount has been claimed. with order id : O-01K32GD4A3AA2K0S2FK3S6614T","2025-08-20 19:33:07","2025-08-20 19:33:07");
