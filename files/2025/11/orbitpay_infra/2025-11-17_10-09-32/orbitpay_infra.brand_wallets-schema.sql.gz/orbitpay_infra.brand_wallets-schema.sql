/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `brand_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` bigint unsigned NOT NULL,
  `available_balance` decimal(20,2) NOT NULL DEFAULT '0.00',
  `pending_balance` decimal(20,2) NOT NULL DEFAULT '0.00',
  `minimum_balance_threshold` decimal(20,2) NOT NULL DEFAULT '1000.00',
  `weekly_minimum_balance_threshold` decimal(20,2) NOT NULL DEFAULT '500.00',
  `withdrawals_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brand_wallets_brand_id_unique` (`brand_id`),
  CONSTRAINT `brand_wallets_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
