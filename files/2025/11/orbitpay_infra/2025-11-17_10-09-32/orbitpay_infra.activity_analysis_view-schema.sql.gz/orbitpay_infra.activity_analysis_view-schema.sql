/*!40101 SET NAMES binary*/;
CREATE TABLE `activity_analysis_view`(
`date` int,
`hour` int,
`brand_id` int,
`type` int,
`attempt_count` int,
`success_count` int,
`volume` int,
`success_rate` int,
`id` int
)ENGINE=MyISAM;
