/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `payouts_cards` VALUES
(1,10,"sadaqatali83@gmail.com","Sada qath",NULL,"push_to_card","4259090021592358","07","29","0","2025-09-24 13:08:02","2025-09-24 13:12:41"),
(2,199,"ziasam447@gmail.com","Mohammed Mohd",NULL,"push_to_card","4259090021592358","07","29","0","2025-10-11 18:50:14","2025-10-11 18:52:22"),
(3,199,"ziasam447@gmail.com","Mohammed Mohd",NULL,"push_to_card","4259090021592358","07","29","0","2025-10-11 19:02:32","2025-10-11 19:03:22"),
(4,199,"ziasam447@gmail.com","Mohammed Mohd",NULL,"push_to_card","4259090021592358","07","29","0","2025-10-11 19:04:16","2025-10-11 19:04:48"),
(5,199,"ziasam447@gmail.com","Mohammed Mohd",NULL,"push_to_card","4259090021592358","07","29","0","2025-10-13 06:45:19","2025-10-13 06:52:13");
