/*!40101 SET NAMES binary*/;
CREATE TABLE `transaction_volumes_view`(
`date` int,
`brand_id` int,
`deposit_count` int,
`deposit_amount` int,
`success_rate` int,
`average_size` int,
`withdrawal_count` int,
`withdrawal_amount` int,
`id` int
)ENGINE=MyISAM;
