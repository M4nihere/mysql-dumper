/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `wallet_reconciliation_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_wallet_id` bigint unsigned NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `records_processed` int NOT NULL DEFAULT '0',
  `memory_usage` int DEFAULT NULL,
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `error_trace` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL,
  `logs` json DEFAULT NULL,
  `discrepancies` json DEFAULT NULL,
  `initial_balance` decimal(20,2) DEFAULT NULL,
  `final_balance` decimal(20,2) DEFAULT NULL,
  `expected_balance` decimal(20,2) DEFAULT NULL,
  `has_discrepancies` tinyint(1) NOT NULL DEFAULT '0',
  `transactions_created` int NOT NULL DEFAULT '0',
  `transactions_updated` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallet_reconciliation_logs_brand_wallet_id_foreign` (`brand_wallet_id`),
  KEY `wallet_reconciliation_logs_job_id_index` (`job_id`),
  CONSTRAINT `wallet_reconciliation_logs_brand_wallet_id_foreign` FOREIGN KEY (`brand_wallet_id`) REFERENCES `brand_wallets` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
