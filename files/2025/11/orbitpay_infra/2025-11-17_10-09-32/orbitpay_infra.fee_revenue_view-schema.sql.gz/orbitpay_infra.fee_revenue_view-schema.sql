/*!40101 SET NAMES binary*/;
CREATE TABLE `fee_revenue_view`(
`date` int,
`brand_id` int,
`deposit_brand_fees` int,
`deposit_stripe_fees` int,
`withdrawal_brand_fees` int,
`withdrawal_checkbook_fees` int,
`total_brand_fees` int,
`total_processor_fees` int,
`net_revenue` int,
`id` int
)ENGINE=MyISAM;
