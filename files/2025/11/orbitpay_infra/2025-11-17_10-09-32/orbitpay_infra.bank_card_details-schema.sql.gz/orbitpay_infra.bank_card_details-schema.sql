/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `bank_card_details` (
  `BIN` int NOT NULL,
  `Brand` varchar(25) NOT NULL,
  `Type` varchar(11) NOT NULL,
  `Category` varchar(34) DEFAULT NULL,
  `Issuer` varchar(98) DEFAULT NULL,
  `IssuerPhone` varchar(59) DEFAULT NULL,
  `IssuerUrl` varchar(50) DEFAULT NULL,
  `isoCode2` varchar(8) NOT NULL,
  `isoCode3` varchar(8) NOT NULL,
  `CountryName` varchar(42) NOT NULL,
  PRIMARY KEY (`BIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
