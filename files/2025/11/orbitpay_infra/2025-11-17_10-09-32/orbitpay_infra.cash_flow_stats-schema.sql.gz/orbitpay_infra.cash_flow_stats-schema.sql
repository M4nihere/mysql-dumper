/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `cash_flow_stats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` bigint unsigned NOT NULL,
  `period_start` timestamp NULL DEFAULT NULL,
  `period_end` timestamp NULL DEFAULT NULL,
  `deposits_count` int NOT NULL DEFAULT '0',
  `deposits_sum_load_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `deposits_sum_brand_fee_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `deposits_sum_player_fee_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `deposits_sum_stripe_fee_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `deposits_sum_amount_paid` decimal(20,2) NOT NULL DEFAULT '0.00',
  `withdrawals_sum_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `withdrawals_sum_check_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `withdrawals_sum_brand_fee_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `withdrawals_sum_player_fee_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `withdrawals_count` int NOT NULL DEFAULT '0',
  `voided_withdrawals_sum_check_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `voided_withdrawals_sum_brand_fee_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `voided_withdrawals_count` int NOT NULL DEFAULT '0',
  `stripe_disputes_count` int NOT NULL DEFAULT '0',
  `stripe_disputes_sum_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `stripe_disputes_sum_fee_amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `net_cash_flow` decimal(20,2) NOT NULL DEFAULT '0.00',
  `last_calculated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_flow_stats_brand_id_period_start_period_end_index` (`brand_id`,`period_start`,`period_end`),
  KEY `cash_flow_stats_period_start_index` (`period_start`),
  KEY `cash_flow_stats_period_end_index` (`period_end`),
  KEY `cash_flow_stats_last_calculated_at_index` (`last_calculated_at`),
  KEY `cash_flow_stats_brand_period_index` (`brand_id`,`period_start`),
  CONSTRAINT `cash_flow_stats_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4996836 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
