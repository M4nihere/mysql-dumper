/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `brand_payment_method_account` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` bigint unsigned NOT NULL,
  `payment_method_account_id` bigint unsigned NOT NULL,
  `enable` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brand_payment_account_unique` (`brand_id`,`payment_method_account_id`),
  KEY `brand_payment_method_account_payment_method_account_id_foreign` (`payment_method_account_id`),
  CONSTRAINT `brand_payment_method_account_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `brand_payment_method_account_payment_method_account_id_foreign` FOREIGN KEY (`payment_method_account_id`) REFERENCES `payment_method_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=930 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
