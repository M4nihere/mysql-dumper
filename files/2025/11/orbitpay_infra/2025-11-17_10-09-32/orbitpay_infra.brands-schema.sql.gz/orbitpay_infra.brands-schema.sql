/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `player_deposit_fee` decimal(10,4) NOT NULL,
  `player_withdrawal_fee` decimal(10,4) NOT NULL,
  `brand_deposit_fee` decimal(10,4) NOT NULL,
  `brand_withdrawal_fee` decimal(10,4) NOT NULL,
  `min_deposit` decimal(10,2) NOT NULL,
  `max_deposit` decimal(10,2) NOT NULL,
  `min_withdrawal` decimal(10,2) NOT NULL,
  `max_withdrawal` decimal(10,2) NOT NULL,
  `withdrawal_percent` int NOT NULL DEFAULT '60',
  `can_deposit` tinyint(1) NOT NULL DEFAULT '1',
  `can_withdraw` tinyint(1) NOT NULL DEFAULT '0',
  `withdrawal_flag_change` enum('auto','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `can_crypto_deposit` tinyint(1) NOT NULL DEFAULT '0',
  `can_cash_app_deposit` tinyint(1) NOT NULL DEFAULT '0',
  `can_transak_deposit` tinyint(1) NOT NULL DEFAULT '0',
  `kyc_required` tinyint(1) NOT NULL DEFAULT '1',
  `deposit_acc_strategy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `withdrawal_acc_strategy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `timezone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'America/Chicago',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `last_user_scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_pma_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
