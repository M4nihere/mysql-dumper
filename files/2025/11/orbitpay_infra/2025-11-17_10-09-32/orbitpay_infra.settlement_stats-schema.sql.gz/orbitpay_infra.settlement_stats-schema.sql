/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `settlement_stats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `brand_id` bigint unsigned NOT NULL,
  `deposits_received` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_fees` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_disputes` decimal(12,2) NOT NULL DEFAULT '0.00',
  `net_deposits` decimal(12,2) NOT NULL DEFAULT '0.00',
  `withdrawal_gross` decimal(12,2) NOT NULL DEFAULT '0.00',
  `withdrawal_fees` decimal(12,2) NOT NULL DEFAULT '0.00',
  `withdrawal_net` decimal(12,2) NOT NULL DEFAULT '0.00',
  `net_cash_flow` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_count` int NOT NULL DEFAULT '0',
  `withdrawal_count` int NOT NULL DEFAULT '0',
  `dispute_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settlement_stats_date_brand_id_unique` (`date`,`brand_id`),
  KEY `settlement_stats_brand_id_foreign` (`brand_id`),
  CONSTRAINT `settlement_stats_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
