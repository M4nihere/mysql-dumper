/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `tickets` VALUES
(1,21,"Deposits","open","Medium","Provident vel sed n","Aut quia ad id reru","156867",NULL,NULL,4385,NULL,NULL,NULL,"2025-11-12 05:29:55","2025-11-12 05:29:55");
