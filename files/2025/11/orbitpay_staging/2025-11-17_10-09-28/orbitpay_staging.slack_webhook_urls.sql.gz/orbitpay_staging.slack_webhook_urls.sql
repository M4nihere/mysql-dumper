/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `slack_webhook_urls` VALUES
(1,"Daily-update","daily","https://hooks.slack.com/services/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","this is daily update webhook url of slack","2025-07-25 06:29:28","2025-07-31 11:31:32"),
(2,"BrandWalletUpdate","brand-wallet-update","https://hooks.slack.com/services/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","this is for brand wallet withdrawal limit low case send notification","2025-07-25 06:56:10","2025-08-22 09:09:25"),
(3,"Slack-update","Slack-update","https://hooks.slack.com/services/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","metor mass replace by slack","2025-07-25 12:59:23","2025-08-22 09:10:17"),
(5,"server-logs","server-logs","https://hooks.slack.com/services/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","this is for the production server log","2025-08-22 07:31:14","2025-08-22 07:31:14"),
(6,"deposit-notifications","deposit-notifications","https://hooks.slack.com/services/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","For the deposit updates","2025-08-22 11:08:19","2025-08-22 11:08:19"),
(7,"withdrawal-notifications","withdrawal-notifications","https://hooks.slack.com/services/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","For the deposit updates","2025-08-22 11:08:57","2025-08-22 11:08:57");
