/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `fee_corrections_backup` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `old_player_fee` decimal(20,2) NOT NULL,
  `old_brand_fee` decimal(20,2) NOT NULL,
  `new_player_fee` decimal(20,2) NOT NULL,
  `new_brand_fee` decimal(20,2) NOT NULL,
  `corrected_at` timestamp NOT NULL,
  `rolled_back` tinyint(1) NOT NULL DEFAULT '0',
  `rolled_back_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
