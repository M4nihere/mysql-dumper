/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `stripe_emails` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `brand_id` bigint unsigned NOT NULL,
  `payment_method_account_id` bigint unsigned NOT NULL,
  `stripe_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stripe_emails_unique` (`email`,`brand_id`),
  UNIQUE KEY `stripe_emails_stripe_id_unique` (`stripe_id`),
  KEY `stripe_emails_brand_id_foreign` (`brand_id`),
  KEY `stripe_emails_payment_method_account_id_foreign` (`payment_method_account_id`),
  KEY `stripe_emails_eb_index` (`email`,`brand_id`),
  KEY `stripe_emails_stripe_id_index` (`stripe_id`),
  KEY `stripe_emails_user_pma_index` (`user_id`,`payment_method_account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=843 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
