/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `i_payouts` VALUES
(1,194,2,"TofikPardeshi","Tofik","Pardeshi","tofik@yopmail.com","123 William Street","New York","NY","10038","United States","13322720602","c391937a-dcd5-437f-aada-27ccc7f5ad01",NULL,NULL,NULL,NULL,NULL,"4111111111111111","CreditCard","12","2030","123","2025-06-16 19:15:33","2025-06-16 19:16:40"),
(2,199,2,"MohammedMohd","Mohammed","Mohd","1989.mzia@gmail.com","123 Sens Road","Bunkie","LA","71322","United States","3322720602","df6fca49-2dc7-47f4-8fc6-8991fde45e02",NULL,NULL,NULL,NULL,NULL,"4111111111111111","CreditCard","12","2030","123","2025-06-16 19:26:05","2025-06-16 19:26:57");
