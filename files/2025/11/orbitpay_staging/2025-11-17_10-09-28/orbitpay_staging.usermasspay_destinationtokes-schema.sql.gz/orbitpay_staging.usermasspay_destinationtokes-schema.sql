/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `usermasspay_destinationtokes` (
  `id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `source_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `destination_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_dynamic_token` tinyint(1) NOT NULL DEFAULT '0',
  `payer_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_variable_fee` tinyint(1) NOT NULL DEFAULT '0',
  `is_generic` tinyint(1) NOT NULL DEFAULT '0',
  `max_limit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `min_limit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `number_of_locations` int unsigned NOT NULL DEFAULT '0',
  `estimated_availability` timestamp NULL DEFAULT NULL,
  `additional_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usermasspay_destinationtokes_user_id_foreign` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
