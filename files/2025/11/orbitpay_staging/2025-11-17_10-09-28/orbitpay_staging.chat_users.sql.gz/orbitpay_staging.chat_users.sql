/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `chat_users` (`convenience_id`,`deleted_at`,`id`,`updated_at`,`user_id`) VALUES
(1,NULL,1,"2025-11-12 05:29:55",4385),
(1,NULL,2,"2025-11-12 05:29:55",1);
