/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `conveniences` (`date_time`,`deleted_at`,`group_image`,`group_name`,`id`,`last_message`,`ticket_id`,`ticket_type`,`type`,`updated_at`) VALUES
(NULL,NULL,NULL,NULL,1,NULL,1,"single_chat","SINGLE","2025-11-12 05:29:55");
