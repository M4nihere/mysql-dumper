/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;

/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `wallet_transactions` (
  `id` bigint unsigned NOT NULL,
  `brand_id` bigint unsigned NOT NULL,
  `brand_wallet_id` bigint unsigned NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(20,2) NOT NULL,
  `previous_available_balance` decimal(12,2) NOT NULL,
  `new_available_balance` decimal(12,2) NOT NULL,
  `previous_pending_balance` decimal(12,2) NOT NULL,
  `new_pending_balance` decimal(12,2) NOT NULL,
  `reference_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallet_transactions_reference_type_reference_id_index` (`reference_type`,`reference_id`),
  KEY `wt_wallet_date_idx` (`brand_wallet_id`,`created_at`),
  KEY `wt_brand_date_idx` (`brand_id`,`created_at`),
  KEY `wt_ref_idx` (`reference_type`,`reference_id`),
  KEY `wt_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
